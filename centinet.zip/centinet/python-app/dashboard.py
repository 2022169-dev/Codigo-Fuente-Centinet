#!/usr/bin/env python3
import os
import socket
from flask import Flask, render_template_string

def get_host_ip():
    """Obtiene la IP local del host."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = "127.0.0.1"
    finally:
        s.close()
    return ip

app = Flask(__name__)

# Si corres este dashboard dentro de docker-compose,
# usa el nombre del servicio de kibana (por defecto: kibana:5601)
# Si lo corres en el host, cambia a http://localhost:5601
KIBANA_URL = os.getenv("KIBANA_URL", "http://kibana:5601")

# Si quieres usar HTTPS o una IP específica (ejemplo):
# KIBANA_URL = "http://localhost:5601"  # cuando se accede desde el host


HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Dashboard de Seguridad de Red</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #343a40;
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 28px;
            letter-spacing: 1px;
        }
        .container {
            padding: 20px;
        }
        .dashboard-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            gap: 25px;
        }
        .dashboard-item {
            flex: 1 1 45%;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 15px;
            min-width: 480px;
        }
        .dashboard-item h2 {
            font-size: 20px;
            color: #222;
            border-bottom: 2px solid #0078d7;
            padding-bottom: 8px;
            margin-bottom: 10px;
        }
        iframe {
            border: none;
            width: 100%;
            height: 360px;
            border-radius: 6px;
        }
        footer {
            text-align: center;
            color: #666;
            padding: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Dashboard de Monitoreo de Seguridad de Red</h1>
    </header>
    <div class="container">
        <div class="dashboard-container">
            <!-- Panel 1 -->
            <div class="dashboard-item">
                <h2>🔒 Conexiones Rechazadas / Intentos Fallidos</h2>
                <p>Muestra el número de intentos de conexión fallidos detectados en los últimos 15 minutos.</p>
                <iframe 
                    src="{{ kibana_url }}/app/dashboards#/view/YOUR_DASHBOARD_ID_1?embed=true&_g=(time:(from:now-15m,to:now))">
                </iframe>
            </div>

            <!-- Panel 2 -->
            <div class="dashboard-item">
                <h2>📡 Tráfico de Red por Protocolo</h2>
                <p>Visualiza el volumen de tráfico dividido por protocolos (TCP, UDP, ICMP, DNS, etc.).</p>
                <iframe 
                    src="{{ kibana_url }}/app/visualize#/edit/YOUR_VISUALIZATION_ID_2?embed=true&_g=(time:(from:now-1h,to:now))">
                </iframe>
            </div>

            <!-- Panel 3 -->
            <div class="dashboard-item">
                <h2>🕒 Tráfico Reciente (Timeline)</h2>
                <p>Visualiza la cronología de los paquetes capturados por el analizador.</p>
                <iframe 
                    src="{{ kibana_url }}/app/dashboards#/view/YOUR_DASHBOARD_ID_3?embed=true&_g=(time:(from:now-30m,to:now))">
                </iframe>
            </div>

            <!-- Panel 4 -->
            <div class="dashboard-item">
                <h2>⚠️ Alertas de Seguridad de Wazuh</h2>
                <p>Resumen de alertas recientes reportadas por Wazuh Manager.</p>
                <iframe 
                    src="{{ kibana_url }}/app/dashboards#/view/YOUR_DASHBOARD_ID_4?embed=true&_g=(time:(from:now-1h,to:now))">
                </iframe>
            </div>
        </div>
    </div>

    <footer>
        <p>Desarrollado con Flask + Kibana + Wazuh © {{ year }}</p>
    </footer>
</body>
</html>
"""
@app.route('/')
def home():
    from datetime import datetime
    return render_template_string(
        HTML_TEMPLATE,
        kibana_url=KIBANA_URL,
        year=datetime.now().year
    )

if __name__ == '__main__':
    host_ip = get_host_ip()
    print(f"📊 Dashboard iniciado en: http://{host_ip}:1777")
    print(f"➡  Integrado con Kibana en: {KIBANA_URL}")
    app.run(host='0.0.0.0', port=1777, debug=True)
