#!/usr/bin/env python3
import os
import pandas as pd
import pyshark
import subprocess
import json
import psycopg2
from datetime import datetime
import requests
import time
import psutil

# Suprime warnings de SSL (solo si usas verify=False)
requests.packages.urllib3.disable_warnings()

class NetworkAnalyzer:
    def __init__(self, es_url, wazuh_base_url, db_config):
        self.es_url = es_url.rstrip('/')
        self.wazuh_base = wazuh_base_url.rstrip('/')
        self.db_conn = None
        try:
            self.db_conn = psycopg2.connect(**db_config)
            print("Conectado a la base de datos PostgreSQL.")
        except psycopg2.Error as e:
            print(f"Error al conectar con PostgreSQL: {e}")

    def interface_detection(self):
        interfaces = psutil.net_if_addrs()
        for nombre, addrs in interfaces.items():
            for addr in addrs:
                if getattr(addr.family, 'name', str(addr.family)) == 'AF_INET' and not addr.address.startswith('127.'):
                    return nombre
        return 'any'

    def capture_packets(self, interface=None, count=100):
        if interface is None:
            interface = self.interface_detection()
        print(f"Usando interfaz: {interface}")

        capture = pyshark.LiveCapture(interface=interface)
        packets = []

        try:
            for packet in capture.sniff_continuously(packet_count=count):
                pkt = {
                    'timestamp': packet.sniff_time.isoformat(),
                    'src_ip': getattr(packet.ip, 'src', None) if hasattr(packet, 'ip') else None,
                    'dst_ip': getattr(packet.ip, 'dst', None) if hasattr(packet, 'ip') else None,
                    'protocol': getattr(packet, 'highest_layer', None),
                    'length': int(getattr(packet, 'length', 0)) if hasattr(packet, 'length') else None,
                    'info_dns': getattr(packet.dns, 'qry_name', None) if hasattr(packet, 'dns') else None
                }
                packets.append(pkt)
        except Exception as e:
            print(f"Error al capturar paquetes: {e}")

        return pd.DataFrame(packets)

    def nmap_scan(self, target):
        try:
            cmd = ["nmap", "-sS", "-O", target, "-oX", "-"]
            result = subprocess.run(cmd, capture_output=True, text=True)
            return result.stdout
        except Exception as e:
            print(f"Error en escaneo Nmap: {e}")
            return None

    def get_wazuh_token(self, user='wazuh', password='wazuh'):
        url = f"{self.wazuh_base}/security/user/authenticate"
        try:
            response = requests.post(url, auth=(user, password), verify=False, timeout=5)
            if response.status_code == 200:
                return response.json().get('data', {}).get('token')
            else:
                print(f"Error al autenticar en Wazuh: {response.status_code} {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"Error de conexión al obtener token: {e}")
        return None

    def send_to_wazuh(self, data):
        token = self.get_wazuh_token()
        if not token:
            print("No se obtuvo token. Saltando envío a Wazuh.")
            return
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        try:
            url = f"{self.wazuh_base}/agents"   # revisar si este endpoint es el apropiado para lo que quieres hacer
            response = requests.post(url, json=data, headers=headers, verify=False, timeout=5)
            if response.status_code in (200,201):
                print("Datos enviados correctamente a Wazuh.")
            else:
                print(f"Error al enviar datos a Wazuh: {response.status_code} {response.text}")
        except requests.exceptions.RequestException as e:
            print(f"Error al enviar datos a Wazuh: {e}")

    def send_to_elasticsearch(self, index_name, records):
        if not records:
            return
        url = f"{self.es_url}/{index_name}/_doc"
        for rec in records:
            try:
                r = requests.post(url, json=rec, timeout=5)
                if r.status_code not in (200,201):
                    print("Error indexando en ES:", r.status_code, r.text)
            except Exception as e:
                print("Excepción indexando en ES:", e)

    def store_log(self, packet_info):
        if not self.db_conn:
            print("No se pudo conectar a la base de datos. Saltando el log.")
            return

        cursor = self.db_conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO trafico_ip (timestamp, origen_ip, destino_ip, protocolo, longitud, info_dns)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (
                packet_info.get('timestamp'),
                packet_info.get('src_ip'),
                packet_info.get('dst_ip'),
                packet_info.get('protocol'),
                packet_info.get('length'),
                packet_info.get('info_dns')
            ))
            self.db_conn.commit()
        except psycopg2.Error as e:
            self.db_conn.rollback()
            print(f"Error en la BD: {e}")
        finally:
            cursor.close()

if __name__ == '__main__':
    # Leer variables desde entorno para flexibilidad
    es_url = os.getenv('ES_URL', 'http://elasticsearch:9200')
    wazuh_url = os.getenv('WAZUH_URL', 'http://wazuh-manager:55000')
    db_config = {
        "host": os.getenv('DB_HOST', 'postgres-db'),
        "user": os.getenv('DB_USER', 'analizador'),
        "password": os.getenv('DB_PASS', 'exp0_centinet'),
        "dbname": os.getenv('DB_NAME', 'logs_de_red')
    }

    analyzer = NetworkAnalyzer(es_url, wazuh_url, db_config)

    if analyzer.db_conn:
        print("Analizador de red en ejecución. Presiona Ctrl+C para detener.")
        try:
            while True:
                packets_df = analyzer.capture_packets(count=50)
                packets_json = packets_df.to_dict('records')

                if packets_json:
                    # Indexar en Elasticsearch
                    analyzer.send_to_elasticsearch("network-traffic", packets_json)
                    print(f"Enviados {len(packets_json)} documentos a Elasticsearch.")

                    # Opcional: enviar a Wazuh (si realmente necesitas)
                    # analyzer.send_to_wazuh(packets_json)

                    for pkt in packets_json:
                        analyzer.store_log(pkt)

                time.sleep(5)
        except KeyboardInterrupt:
            print("Analizador de red detenido.")
        finally:
            analyzer.db_conn.close()
    else:
        print("No se pudo iniciar el analizador debido a un error de conexión a la base de datos.")
